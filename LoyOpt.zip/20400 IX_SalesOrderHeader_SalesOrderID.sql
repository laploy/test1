--220400 IX_SalesOrderHeader_SalesOrderID: laploy, June 2025 
USE LoyDB2025;
GO

-- Drop the index if it exists
IF EXISTS (
    SELECT 1 
    FROM sys.indexes 
    WHERE name = 'IX_SalesOrderHeader_SalesOrderID'
      AND object_id = OBJECT_ID('dbo.SalesOrderHeader')
)
BEGIN
    DROP INDEX IX_SalesOrderHeader_SalesOrderID ON dbo.SalesOrderHeader;
END
GO

-- Create the nonclustered index
CREATE NONCLUSTERED INDEX IX_SalesOrderHeader_SalesOrderID
ON dbo.SalesOrderHeader (SalesOrderID)
INCLUDE (CustomerID);
GO