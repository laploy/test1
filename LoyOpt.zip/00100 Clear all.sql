-- clear all 

USE LoyDB2025;
GO

-- Drop the index if it exists
IF EXISTS (
    SELECT 1 
    FROM sys.indexes 
    WHERE name = 'IX_SalesOrderHeader_TerritoryID'
      AND object_id = OBJECT_ID('dbo.SalesOrderHeader')
)
BEGIN
    DROP INDEX IX_SalesOrderHeader_TerritoryID ON dbo.SalesOrderHeader;
END
GO

-- Drop the index if it exists
IF EXISTS (
    SELECT 1 
    FROM sys.indexes 
    WHERE name = 'IX_SalesOrderDetail_SalesOrderDetailID'
      AND object_id = OBJECT_ID('dbo.SalesOrderDetail')
)
BEGIN
    DROP INDEX IX_SalesOrderDetail_SalesOrderDetailID ON SalesOrderDetail;
END
GO

-- Drop the index if it exists
IF EXISTS (
    SELECT 1 
    FROM sys.indexes 
    WHERE name = 'IX_SalesOrderHeader_SalesOrderID'
      AND object_id = OBJECT_ID('dbo.SalesOrderHeader')
)
BEGIN
    DROP INDEX IX_SalesOrderHeader_SalesOrderID ON dbo.SalesOrderHeader;
END
GO

-- Drop the view if it exists
IF OBJECT_ID('dbo.vSalesOrderDetail', 'V') IS NOT NULL
BEGIN
    DROP VIEW dbo.vSalesOrderDetail;
END
GO
