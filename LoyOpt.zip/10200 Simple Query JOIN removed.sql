-- 10200 Simple Query JOIN removed: laploy, June 2025 
USE LoyDB2025;
GO

SELECT 
	CustomerID,
	TerritoryID,
	od.OrderQty,
	od.LineTotal,
	od.SalesOrderDetailID,
	oh.SalesOrderID
FROM SalesOrderDetail od
	JOIN SalesOrderHeader oh
		ON od.SalesOrderID = oh.SalesOrderID 
GO