-- 40400 Crate View: laploy, June 2025 
USE LoyDB2025;
GO

--Set the options to support indexed views.
SET NUMERIC_ROUNDABORT OFF;
SET ANSI_PADDING,
    ANSI_WARNINGS,
    CONCAT_NULL_YIELDS_NULL,
    ARITHABORT,
    QUOTED_IDENTIFIER,
    ANSI_NULLS ON;

-- Drop the view if it exists
IF OBJECT_ID('dbo.vSalesOrderDetail', 'V') IS NOT NULL
BEGIN
    DROP VIEW dbo.vSalesOrderDetail;
END
GO

--Create view with SCHEMABINDING.
CREATE VIEW dbo.vSalesOrderDetail
    WITH SCHEMABINDING
AS
SELECT 
    CustomerID,
    TerritoryID,
    SalesOrderDetail.OrderQty,
    SalesOrderDetail.LineTotal,
    SalesOrderDetail.SalesOrderDetailID,
    SalesOrderHeader.SalesOrderID

FROM dbo.SalesOrderDetail
JOIN dbo.SalesOrderHeader 
    ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID 
GO

--Create an index on the view.
CREATE UNIQUE CLUSTERED INDEX IDX_V1 ON  dbo.vSalesOrderDetail (
    SalesOrderDetailID,
    TerritoryID
);
GO