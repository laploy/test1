-- 40400 Crate View.sql: laploy, June 2025 
USE LoyDB2025;
GO

-- Drop the view if it exists
IF OBJECT_ID('dbo.vSalesOrderDetail', 'V') IS NOT NULL
BEGIN
    DROP VIEW dbo.vSalesOrderDetail;
END
GO

--Create view with SCHEMABINDING.
CREATE VIEW dbo.vSalesOrderDetail
    WITH SCHEMABINDING
AS
SELECT 
    CustomerID,
    TerritoryID,
    SalesOrderDetail.OrderQty,
    SalesOrderDetail.LineTotal,
    SalesOrderDetail.SalesOrderDetailID,
    SalesOrderHeader.SalesOrderID

FROM dbo.SalesOrderDetail
JOIN dbo.SalesOrderHeader 
    ON SalesOrderDetail.SalesOrderID = SalesOrderHeader.SalesOrderID 
GO

--Create an index on the view.
CREATE UNIQUE CLUSTERED INDEX IDX_V1 ON  dbo.vSalesOrderDetail (
    SalesOrderDetailID,
    TerritoryID
);
GO