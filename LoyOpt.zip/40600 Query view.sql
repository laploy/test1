-- 40600 Query view.sqll: laploy, June 2025 

USE LoyDB2025;
GO

SELECT *
FROM vSalesOrderDetail  WITH (NOEXPAND)
WHERE SalesOrderDetailID = 61037 AND territoryID = 7;
GO