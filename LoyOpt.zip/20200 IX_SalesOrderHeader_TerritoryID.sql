-- 20200 IX_SalesOrderHeader_TerritoryID: laploy, June 2025 
USE LoyDB2025;
GO

-- Drop the index if it exists
IF EXISTS (
    SELECT 1 
    FROM sys.indexes 
    WHERE name = 'IX_SalesOrderHeader_TerritoryID'
      AND object_id = OBJECT_ID('dbo.SalesOrderHeader')
)
BEGIN
    DROP INDEX IX_SalesOrderHeader_TerritoryID ON dbo.SalesOrderHeader;
END
GO

-- Create the recommended nonclustered index
CREATE NONCLUSTERED INDEX IX_SalesOrderHeader_TerritoryID
ON dbo.SalesOrderHeader (TerritoryID)
INCLUDE (SalesOrderID, CustomerID);
GO
