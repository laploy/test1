-- 10300 Query with Filter: laploy, June 2025 
USE LoyDB2025;
GO

SELECT 
	CustomerID,
	TerritoryID,
	od.OrderQty,
	od.LineTotal,
	od.SalesOrderDetailID,
	oh.SalesOrderID
FROM SalesOrderDetail od 
	JOIN SalesOrderHeader oh
		ON od.SalesOrderID = oh.SalesOrderID 
WHERE od.SalesOrderDetailID = 61037 AND oh.territoryID = 7;
GO