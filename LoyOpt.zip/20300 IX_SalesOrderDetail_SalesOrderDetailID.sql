--20300 IX_SalesOrderDetail_SalesOrderDetailID: laploy, June 2025 
USE LoyDB2025;
GO

-- Drop the index if it exists
IF EXISTS (
    SELECT 1 
    FROM sys.indexes 
    WHERE name = 'IX_SalesOrderDetail_SalesOrderDetailID'
      AND object_id = OBJECT_ID('dbo.SalesOrderDetail')
)
BEGIN
    DROP INDEX IX_SalesOrderDetail_SalesOrderDetailID ON SalesOrderDetail;
END
GO

-- Create the nonclustered index
CREATE NONCLUSTERED INDEX IX_SalesOrderDetail_SalesOrderDetailID
ON SalesOrderDetail (SalesOrderDetailID);
GO