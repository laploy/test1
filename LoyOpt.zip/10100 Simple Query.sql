-- 10100 Simple Query: laploy, June 2025 
USE LoyDB2025;
GO

SELECT 
	c.CustomerID,
	c.TerritoryID,
	od.OrderQty,
	od.LineTotal,
	od.SalesOrderDetailID,
	oh.SalesOrderID
FROM SalesOrderDetail od
	JOIN SalesOrderHeader oh
		ON od.SalesOrderID = oh.SalesOrderID 
	JOIN Customer c
		ON oh.CustomerID = c.CustomerID
GO