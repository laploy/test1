-- 20100 check uniqueness: laploy, June 2025 
USE LoyDB2025;
GO

USE LoyDB2025;
GO

SELECT SalesOrderDetailID, COUNT(*) AS Occurrences
FROM dbo.SalesOrderDetail
GROUP BY SalesOrderDetailID
HAVING COUNT(*) > 1;